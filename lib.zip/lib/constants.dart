const int kThemeColor = 0xffcd042e;
const String kWelcomePageAppDescription =
    'UPJ Digital Canteen merupakan aplikasi yang dibangun untuk menciptakan suasanan dan rasa ketertiban para Civitas UPJ dalam bertransaksi di kantin.';
const String kWelcomeText = 'Welcome to UPJ Digital Canteen';
